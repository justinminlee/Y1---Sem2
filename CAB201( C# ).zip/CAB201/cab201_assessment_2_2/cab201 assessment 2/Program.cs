﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;
using System.Collections;

namespace Auction_place
{


    // This will be used when user info required

    class User
    {
        public static int Index_of_name(string username)
        {
            string[] UserArray = File.ReadAllLines(@"User.txt");
            ArrayList userarray = new (UserArray);
            int user_index = userarray.IndexOf(username);
            return user_index;

        }
        public static int Index_of_email(string useremail)
        {
            string[] UserArray = File.ReadAllLines(@"User.txt");
            ArrayList userarray = new (UserArray);
            int user_index = userarray.IndexOf(useremail);
            return user_index;

        }
        public static string Username(int index)
        {
            string[] UserArray = File.ReadAllLines(@"User.txt");
            ArrayList userarray = new (UserArray);
            string username = Convert.ToString(userarray[index]);
            return username;
        }
        public static string Useremail(int index)
        {
            string[] UserArray = File.ReadAllLines(@"User.txt");
            ArrayList userarray = new (UserArray);
            string useremail = Convert.ToString(userarray[index]);
            return useremail;
        }
    }
    // This will be used when product needs to be found



    // This makes the code more clear
    class Useful_tools
    {
        public static void Linechanger(string newText, string txtName, int line_to_edit)
        {
            string[] allLine = File.ReadAllLines(txtName);
            allLine[line_to_edit - 1] = newText;
            File.WriteAllLines(txtName, allLine);

        }
        public static void Write(string Text, string txtname)
        {
            using (StreamWriter sr = new(txtname, append: true))
            {
                sr.WriteLine(Text);
            }
        }
    }


    // Starting the code
    class Main_Menu
    {



        // Main menu
        public static void Main()
        {
            Console.WriteLine("+============================+");
            Console.WriteLine("|Welcome to the Auction House|");
            Console.WriteLine("+============================+");
            // Starting while loop to come back when input value is invalid
            while (true)
            {

                Console.WriteLine("\nMain Menu");
                Console.WriteLine("---------");
                Console.WriteLine("(1) Register");
                Console.WriteLine("(2) Sign In");
                Console.WriteLine("(3) Exit");
                Console.WriteLine("\nPlease select an option between 1 and 3");
                string Option = Console.ReadLine();
                // Start registration when input is 1
                switch (Option)
                {


                    case "1":

                        // Get name email and password from users
                        string name = Option_1.Username();
                        string email = Option_1.Useremail();
                        string password = Option_1.Userpassword();
                        Console.WriteLine("Client " + name + "(" + email + ") has successfully registered at the Auction House");

                        // Save new user info on the text file
                        Useful_tools.Write(name, "User.txt");
                        Useful_tools.Write(email, "User.txt");
                        Useful_tools.Write(password, "User.txt");
                        break;
                    // Start signin when input is 2
                    case "2":
                        Option_2.User_info_validation();
                        break;

                    case "3":

                        Console.WriteLine("+--------------------------------------------------+");
                        Console.WriteLine("| Good bye, thank you for using the Auction House! |");
                        Console.WriteLine("+--------------------------------------------------+");
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\nPlease select an option between 1 and 3");
                        break;               
                }
            }
        }
    }
    // Start Client menu
    class Client_menu
    {
        public static void Client(int i)
        {
            // Looping client menu unless user input 6
            while (true)
            {

                Console.WriteLine("\nClient Menu");
                Console.WriteLine("-------------");
                Console.WriteLine("(1) Advertise Product");
                Console.WriteLine("(2) View My Product List");
                Console.WriteLine("(3) Search For Advertised Product");
                Console.WriteLine("(4) View Bids On My Products");
                Console.WriteLine("(5) View My Purchased Items");
                Console.WriteLine("(6) Log off");
                Console.WriteLine("\nPlease select an option between 1 and 6");

                // Specify logged in user 
                string name = User.Username(i - 1);
                string email = User.Useremail(i);
                string client_option = Console.ReadLine();
                // Start switch to go back and forwards easily
                switch (client_option)
                {

                    // Advertise product when user provided 1
                    case "1":


                        Console.WriteLine("\nProduct Advertisement for " + name + "(" + email + ")");
                        Console.WriteLine("---------------------------------------------------------------------------------------");
                        Console.WriteLine("\nProduct name");
                        string ads = Client_option.Product_advertisement(i);
                        Console.WriteLine(ads);
                        break;
                    // List advertised product by logged in user when user provided 2
                    case "2":

                        Console.WriteLine("\nProduct list for " + name + "(" + email + ")");
                        Console.WriteLine("---------------------------------------------------------------------");
                        Console.WriteLine("\nItem #          Product name          Description          List price          Bidder name          Bidder email          Bid amt");
                        string w = Client_option.My_advertised_product(i);
                        break;
                    // List all products that has been advertised by other users when user provided 3
                    case "3":

                        Console.WriteLine("\nProduct search for " + name + "(" + email + ")");
                        Console.WriteLine("---------------------------------------------");
                        Console.WriteLine("\nPlease supply a search phrase (ALL to see all products)");
                        string search_phrase = Console.ReadLine();
                        Client_option.Search_product(search_phrase, i);
                        break;
                    // List logged in user's product that has bid on it when user provided 4
                    case "4":
                        Client_option.Confirm_bid(i);
                        break;
                    // List purchased product by user when user provided 5
                    case "5":
                        Client_option.My_product(i);
                        break;
                    // Execute Client menu and go back to Main menu
                    case "6":
                        Main_Menu.Main();
                        break;
                    // Loop the client menu if user provided none of the above
                    default:
                        Console.WriteLine("\nPlease select an option between 1 and 6");
                        break;
                }
            }
        }
    }


    // The functions belonged in Option_1 will be used to registration
    class Option_1
    {

        public static string Username()
        {
            while (true)
            {
                Console.WriteLine("\nPlease enter your name");
                string Name = Console.ReadLine();
                string Name_check = @"^[a-zA-Z].{2,}$";
                // Regex is used to check if user name is valid name
                if (Regex.IsMatch(Name, Name_check))
                {
                    return Name;
                }
                else
                {
                    Console.WriteLine("     The supplied value is not a valid name.");
                }
            }
        }
        public static string Useremail()
        {
            while (true)
            {
                
                Console.WriteLine("\nPlease enter your email address");

                string email = Console.ReadLine();
                string email_check = @"[A-Za-z0-9._-]+[A-Za-z0-9]+@+[A-Za-z0-9_-]+.+[A-Za-z0-9._-]+[A-Za-z0-9_-]";
                // Regex is used to check if user email is valid
                if (Regex.IsMatch(email, email_check))
                {
                    string[] emailArray = File.ReadAllLines(@"User.txt");
                    if (emailArray.Contains(email) == false)
                    {
                        return email;
                    }
                    else
                    {
                        Console.WriteLine("     The supplied address is already in use.");
                    }


                }
                else
                {
                    Console.WriteLine("     The supplied value is not a valid email address.");
                }
            }
        }

        public static string Userpassword()
        {
            Console.WriteLine("\nPlease choose a password");
            Console.WriteLine("* At least 8 characters");
            Console.WriteLine("* No white space characters");
            Console.WriteLine("At least one upper-case letter");
            Console.WriteLine("At least one lower-case letter");
            Console.WriteLine("At least one digit");
            Console.WriteLine("At elast one special character");
            while (true)
            {

                string password = Console.ReadLine();
                string password_check = @"^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[\W]).{8,32}$";
                // Regex is used to check if user provided valid password
                if (Regex.IsMatch(password, password_check))
                {
                    return password;
                }
                else
                {
                    Console.WriteLine("     The supplied value is not a valid password");
                }
            }
        }
    }

    // Option 2 will be used for sign in 
    class Option_2
    {
        public static int Id_match()
        {
            Console.WriteLine("\nSign In");
            Console.WriteLine("------------");


            while (true)
            {
                Console.WriteLine("\nPlease enter your email address");
                string Input_Email = Console.ReadLine();
                string email_check = @"[A-Za-z0-9._-]+[A-Za-z0-9]+@+[A-Za-z0-9_-]+.+[A-Za-z0-9._-]+[A-Za-z0-9_-]";
                if (Regex.IsMatch(Input_Email, email_check))
                {
                    string[] UserArray = File.ReadAllLines(@"User.txt");
                    ArrayList userarray = new(UserArray);
                    // Check user input if the user email is exists on the data base (which called User.txt)
                    if (userarray.Contains(Input_Email))
                    {
                        // If it exists, get the index of user input email
                        int listNo = userarray.IndexOf(Input_Email);
                        return listNo;
                    }
                    else
                    {
                        Console.WriteLine("     The supplied email address is not exist");
                    }

                }
                else
                {
                    Console.WriteLine("     The supplied value is not a valid email address.");
                }

            }
        }
        public static string User_validation()
        {
            // Bring list number (index number of user input email) from previous function
            int listNo = Id_match();
            while (true)
            {
                string[] UserArray = File.ReadAllLines(@"User.txt");
                ArrayList Userarray = new(UserArray);
                Console.WriteLine("\nPlease enter your password");
                string Input_Password = Console.ReadLine();
                // Convert list number to password by adding 1 to read next line on the User.txt file
                string check_pass = Convert.ToString(Userarray[listNo + 1]);
                // Check if user input password is same as password converted from list number 
                if (Input_Password == check_pass)
                {
                    string useremail = Convert.ToString(Userarray[listNo]);
                    return useremail;
                }
                else
                {
                    Console.WriteLine("     The supplied password is not correct");

                }
            }
        }
        // Check whether if user already provided user address or not
        public static void User_info_validation()
        {
            string useremail = User_validation();
            int index_of_email = User.Index_of_email(useremail);
            string[] UserinfoArray = File.ReadAllLines(@"Userinfo.txt");
            ArrayList Userinfo = new(UserinfoArray);
            int i = User.Index_of_email(useremail);
            if (Userinfo.Contains(useremail) == false)
            {
                Write_user_info(useremail);

            }
            else
            {
                Client_menu.Client(i);
            }

        }

        // Get user address
        public static void Write_user_info(string useremail)
        {
            Console.WriteLine("-------------------------------------------------------------------------------");
            Console.WriteLine("\nPlease provide your home address.");
            int unitnumber = Unitnumber();
            int streetnumber = Streetnumber();
            Console.WriteLine("\nStreet name:");
            string streetname = Console.ReadLine();
            Console.WriteLine("\nStreet suffix:");
            string streetsuffix = Console.ReadLine();
            Console.WriteLine("\nCity:");
            string city = Console.ReadLine();
            string state = State();
            int postcode = Postcode();
            Console.WriteLine("\n Address has been updated to " + unitnumber + " " + streetnumber + " " + streetname + " " + streetsuffix + ", " + city + " " + state + " " + postcode);
            string unit_number = Convert.ToString(unitnumber);
            string street_number = Convert.ToString(streetnumber);
            string post_code = Convert.ToString(postcode);
            Useful_tools.Write(useremail, "Userinfo.txt");
            Useful_tools.Write(unit_number, "Userinfo.txt");
            Useful_tools.Write(street_number, "Userinfo.txt");
            Useful_tools.Write(streetname, "Userinfo.txt");
            Useful_tools.Write(streetsuffix, "Userinfo.txt");
            Useful_tools.Write(city, "Userinfo.txt");
            Useful_tools.Write(state, "Userinfo.txt");
            Useful_tools.Write(post_code, "Userinfo.txt");
            int i = User.Index_of_email(useremail);
            Client_menu.Client(i);

        }

        // Get unit number of user address
        public static int Unitnumber()
        {
            while (true)
            {
                Console.WriteLine("\nUnit number (0 = none):");
                string str_Unit = Console.ReadLine();
                int Unit = Int32.Parse(str_Unit);
                if (Unit < 0)
                {
                    Console.WriteLine("     Unit number must be a non-negative integer.");
                }
                else if (Unit > -1)
                {
                    return Unit;
                }
                else
                {
                    Console.WriteLine("     Unit number must be a non-negative integer.");
                }
            }
        }
        //  Get street number of user address
        public static int Streetnumber()
        {
            while (true)
            {

                Console.WriteLine("\nStreet number:");
                string str_streetnumber = Console.ReadLine();
                int streetnumber = Int32.Parse(str_streetnumber);
                if (streetnumber > 0)
                {
                    return streetnumber;
                }
                else if (streetnumber < 0)
                {
                    Console.WriteLine("     Street number must be greater than 0");

                }
                else
                {
                    Console.WriteLine("     Street number must be as positive integer");
                }
            }
        }
        // Get state of user address
        public static string State()
        {
            Console.WriteLine("\nState (ACT, NSW, NT, QLD, SA, TAS, VIC, WA):");

            List<string> State_examples = new List<string>();
            State_examples.Add("ACT");
            State_examples.Add("NSW");
            State_examples.Add("NT");
            State_examples.Add("QLD");
            State_examples.Add("SA");
            State_examples.Add("TAS");
            State_examples.Add("VIC");
            State_examples.Add("WA");
            while (true)
            {

                string user_state = Console.ReadLine();
                if (State_examples.Contains(user_state, StringComparer.OrdinalIgnoreCase))
                {
                    string upper_user_state = user_state.ToUpper();
                    return upper_user_state;
                }
                else
                {
                    Console.WriteLine("Please provide existing state");
                }
            }
        }

        // Get postcode of user address
        public static int Postcode()
        {
            while (true)
            {


                Console.WriteLine("\nPostcode (1000 .. 9999)");
                string str_postcode = Console.ReadLine();
                int postcode = Int32.Parse(str_postcode);
                if (postcode < 1000)
                {
                    Console.WriteLine("     Postcode must be bigger than 999");

                }
                else if (postcode > 9999)
                {
                    Console.WriteLine("     Postcode must be smaller than 10000");
                }
                else
                {
                    return postcode;
                }
            }
        }
    }


    // Start Client option if user logged in
    class Client_option
    {

        // Advertise user's product
        public static string Product_advertisement(int email)
        {

            // Get user email to specify logged in user
            string useremail = User.Useremail(email);
            string product_name = Console.ReadLine();
            Console.WriteLine("\nProduct description");
            string product_description = Console.ReadLine();
            while (true)
            {
                Console.WriteLine("\nProduct price ($d.cc)");
                string product_price = Console.ReadLine();
                string Price_check = @"([$]) *([0-9.,]*)";
                if (Regex.IsMatch(product_price, Price_check))
                {
                    string bidder_name = ("-");
                    string bidder_email = ("-");
                    string bid_amount = ("-");
                    string delivery_option = ("-");
                    string product_added = ("\nSuccessfully added product " + product_name + ", " + product_description + ", " + product_price);

                    // Save each product information on product text file that has been seperated
                    Useful_tools.Write(useremail, "Product.txt");
                    Useful_tools.Write(product_name, "Product.txt");
                    Useful_tools.Write(product_description, "Product.txt");
                    Useful_tools.Write(product_price, "Product.txt");
                    Useful_tools.Write(useremail, "Product_email.txt");
                    Useful_tools.Write(product_name, "Product_name.txt");
                    Useful_tools.Write(product_description, "Product_description.txt");
                    Useful_tools.Write(product_price, "Product_price.txt");
                    // Save each bid information on bid text file that has been separated
                    // bid information is -(blank) at the moment
                    Useful_tools.Write(useremail, "Bid.txt");
                    Useful_tools.Write(bidder_name, "Bid.txt");
                    Useful_tools.Write(bidder_email, "Bid.txt");
                    Useful_tools.Write(bid_amount, "Bid.txt");
                    Useful_tools.Write(bidder_name, "Bidder_name.txt");
                    Useful_tools.Write(bidder_email, "Bidder_email.txt");
                    Useful_tools.Write(bid_amount, "Bid_amount.txt");
                    Useful_tools.Write(useremail, "Bid_owner_email.txt");
                    Useful_tools.Write(delivery_option, "Delivery_option.txt");
                    return product_added;
                }
                else
                {
                    Console.WriteLine("     A Currency value is required, e.g. $54.95, $3.21, $2314.21");
                }
            }
        }

        // Check advertised product by logged in user
        public static string My_advertised_product(int email)
        {
            string[] product_emailArray = File.ReadAllLines(@"Product.txt");
            ArrayList product_email = new(product_emailArray);
            string[] product_nameArray = File.ReadAllLines(@"Product.txt");
            ArrayList product_name = new(product_nameArray);
            string[] product_descriptionArray = File.ReadAllLines(@"Product.txt");
            ArrayList product_description = new(product_descriptionArray);
            string[] product_priceArray = File.ReadAllLines(@"Product.txt");
            ArrayList product_price = new(product_priceArray);


            string[] bidder_nameArray = File.ReadAllLines(@"Bid.txt");
            ArrayList bidder_name = new(bidder_nameArray);
            string[] bidder_emailArray = File.ReadAllLines(@"Bid.txt");
            ArrayList bidder_email = new(bidder_emailArray);
            string[] bid_amountArray = File.ReadAllLines(@"Bid.txt");
            ArrayList bid_amount = new(bid_amountArray);
            string[] useremailArray = File.ReadAllLines(@"Bid.txt");
            ArrayList useremail = new(useremailArray);


            string email_check = User.Useremail(email);
            int c = 0;

            // This finds out the index that has logged in user email as product email on product email array which is already advertised by some user

            int[] VALUE = product_emailArray.Select((b, i) => b == email_check ? i : -1).Where(i => i != -1).ToArray();

            foreach (int a in VALUE)
            {
                c++;
                Console.WriteLine(c + "                  " + product_name[a + 1] + "                  " + product_description[a + 2] + "                  " + product_price[a + 3] + "                  " + bidder_name[a + 1] + "                  " + bidder_email[a + 2] + "                  " + bid_amount[a + 3]);
            }
            string w = "done";
            return w;
        }

        // Get delivery option that user prefer
        public static void Delivery_option(int Input_product_number)
        {
            Console.WriteLine("\nDelivery Instructions");
            Console.WriteLine("-----------------------");
            Console.WriteLine("(1) Click and collect");
            Console.WriteLine("(2) Home Delivery");
            Console.WriteLine("\nPlease select an option between 1 and 2");
            string delivery_option = Console.ReadLine();
            if (delivery_option == "1")
            {
                while (true)
                {

                    // This will be used to user collect the product
                    Console.WriteLine("\nDelivery window start (dd/mm/yyyy hh:mm)");
                    // string 'now' record the current time
                    string now = DateTime.Now.AddHours(1).ToString("dd/MM/yyyy HH:mm");
                    DateTime dt1 = DateTime.ParseExact(now, "dd/MM/yyyy HH:mm", null);
                    DateTime check_window_start = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy HH:mm", null);
                    TimeSpan time_diff = check_window_start - dt1;
                    int diff_hour = time_diff.Hours;

                    if (diff_hour < 0)
                    {
                        Console.WriteLine("     Delivery window start must be at least one hour in the future");

                    }
                    else if (diff_hour >= 0)
                    {
                        while (true)
                        {
                            Console.WriteLine("\nDelivery window end (dd/mm/yyyy hh:mm)");
                            DateTime check_window_end = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy HH:mm", null);
                            TimeSpan time_diff2 = check_window_end - check_window_start;
                            int diff_hour2 = time_diff2.Hours;
                            if (diff_hour2 < 0)
                            {
                                Console.WriteLine("     Deliver window end must be at least one hour later than the start");

                            }
                            else if (diff_hour2 > 0)
                            {
                                Console.WriteLine("\nThank you for your bid. If successful, the item will be provided via collection between " + check_window_start.ToString("HH:mm") + " on " + check_window_start.ToString("dd/MM/yyyy") + " and " + check_window_end.ToString("HH:mm") + " on " + check_window_end.ToString("dd/MM/yyyy"));
                                Useful_tools.Linechanger("Collect item between" + check_window_start.ToString("HH:mm") + " on " + check_window_start.ToString("dd/MM/yyyy") + " and " + check_window_end.ToString("HH:mm") + " on " + check_window_end.ToString("dd/MM/yyyy"), "Delivery_option.txt", Input_product_number);
                                break;
                            }
                            else
                            {
                                Console.WriteLine(diff_hour2);
                                Console.WriteLine("     Please enter a valid date and time");
                            }
                        }
                        break;
                    }
                    else
                    {
                        Console.WriteLine("     Please enter a valid date and time");
                    }
                }
                
                
            }
            // This will be used to deliver product to user's address (getting user's address once again)
            else if (delivery_option == "2")
            {
                Console.WriteLine("\nPlease provide your delivery address");
                int unitnumber = Option_2.Unitnumber();
                int streetnumber = Option_2.Streetnumber();
                Console.WriteLine("\nStreet name:");
                string streetname = Console.ReadLine();
                Console.WriteLine("\nStreet suffix:");
                string streetsuffix = Console.ReadLine();
                Console.WriteLine("\nCity:");
                string city = Console.ReadLine();
                string state = Option_2.State();
                int postcode = Option_2.Postcode();
                Console.WriteLine("\n Thank you for your bid. If successful, the item will provided via delivery to " + unitnumber + "/" + streetnumber + " " + streetname + " " + streetsuffix + ", " + city + " " + state + " " + postcode);
                Useful_tools.Linechanger("delivery to " + unitnumber + "/" + streetnumber + " " + streetname + " " + streetsuffix + ", " + city + " " + state + " " + postcode, "Delivery_option.txt", Input_product_number);

            }

        }


        // Search product by search phrase that user proivded
        public static void Search_product(string search_phrase, int email)
        {


            
            string[] product_emailArray = File.ReadAllLines(@"Product_email.txt");
            ArrayList product_email = new(product_emailArray);
            string[] product_nameArray = File.ReadAllLines(@"Product_name.txt");
            ArrayList product_name = new(product_nameArray);
            string[] product_descriptionArray = File.ReadAllLines(@"Product_description.txt");
            ArrayList product_description = new(product_descriptionArray);
            string[] product_priceArray = File.ReadAllLines(@"Product_price.txt");
            ArrayList product_price = new(product_priceArray);
            ArrayList listproduct_name = new ArrayList();
            ArrayList listproduct_description = new ArrayList();
            ArrayList listproduct_price = new ArrayList();
            ArrayList listbidder_name = new ArrayList();
            ArrayList listbidder_email = new ArrayList();
            ArrayList listbid_amount = new ArrayList();
            ArrayList listdelivery_option = new ArrayList();


            string[] bidder_nameArray = File.ReadAllLines(@"Bidder_name.txt");
            ArrayList bidder_name = new(bidder_nameArray);
            string[] bidder_emailArray = File.ReadAllLines(@"Bidder_email.txt");
            ArrayList bidder_email = new(bidder_emailArray);
            string[] bid_amountArray = File.ReadAllLines(@"Bid_amount.txt");
            ArrayList bid_amount = new(bid_amountArray);
            string[] useremailArray = File.ReadAllLines(@"Bid_owner_email.txt");
            ArrayList useremail = new(useremailArray);
            string[] delivery_optionArray = File.ReadAllLines(@"Delivery_option.txt");
            ArrayList delivery_option = new(delivery_optionArray);


            string Useremail = User.Useremail(email);
            string Username = User.Username(email - 1);
            // List all the product if user provided all (upper case and lower case won't matter)
            if (search_phrase.ToUpper() == "ALL")
            {
                int g = 0;
                int[] VALUE = product_emailArray.Select((b, i) => b != Useremail ? i : -1).Where(i => i != -1).ToArray();

                Console.WriteLine("--------------");
                Console.WriteLine("\nItem #          Product name          Description          List price          Bidder name          Bidder email          Bid amt");
                foreach (int i in VALUE)
                {

                    // Add searched product on new list to match listed product and the actual product saved on the product file
                    listproduct_name.Add(product_name[i]);
                    listproduct_description.Add(product_description[i]);
                    listproduct_price.Add(product_price[i]);
                    listbidder_name.Add(bidder_name[i]);
                    listbidder_email.Add(bidder_email[i]);
                    listbid_amount.Add(bid_amount[i]);
                    listdelivery_option.Add(delivery_option[i]);
                    g++;
                    Console.WriteLine(g + "                  " + product_name[i] + "                  " + product_description[i] + "                  " + product_price[i] + "                  " + bidder_name[i] + "                  " + bidder_email[i] + "                  " + bid_amount[i]);

                }

                if (g < 1)
                {
                    Console.WriteLine("None of the product have been searched");
                }
                else if (g >= 1)
                {

                    // Put bids on product that user selected
                    Console.WriteLine("Would you like to place a bid on any of these items (yes or no)?");
                    string response = Console.ReadLine();

                    if (response.ToLower() == "yes")
                    {

                        while (true)
                        {

                            Console.WriteLine("Please enter a non-negative integer between 1 and " + g);
                            string str_Input_product_number = Console.ReadLine();
                            int input_product_number = Int32.Parse(str_Input_product_number);
                            int Input_product_number = input_product_number;
                            if (Input_product_number > 1 | Input_product_number < g + 1)
                            {
                                // Input product number by user has 1 bigger than the index of product because index starts with 0 but list product number starts with 1
                                string is_bid_0 = Convert.ToString(listbid_amount[Input_product_number - 1]);

                                if (is_bid_0 == "-")
                                {

                                    while (true)
                                    {
                                        string current_bid_amount = "$0.00";
                                        Console.WriteLine("\nBidding for " + listproduct_name[Input_product_number - 1] + "(regular price " + listproduct_price[Input_product_number - 1] + "), current highest bid " + current_bid_amount);
                                        Console.WriteLine("\nHow much do you bid?");
                                        string bid_price = Console.ReadLine();
                                        string Price_check = @"([$]) *([0-9.,]*)";
                                        // regex is used to check if user provided proper formatted price

                                        if (Regex.IsMatch(bid_price, Price_check))
                                        {
                                            string find_index_of_product = Convert.ToString(listproduct_name[Input_product_number -1]);
                                            int index_of_product = product_name.IndexOf(find_index_of_product);
                                            Useful_tools.Linechanger(Useremail, "Bidder_email.txt", index_of_product);
                                            Useful_tools.Linechanger(Username, "Bidder_name.txt", index_of_product);
                                            Useful_tools.Linechanger(bid_price, "Bid_amount.txt", index_of_product);
                                            string returns = ("\nYour bid of " + bid_price + " for " + listproduct_name[Input_product_number - 1] + "is placed.");
                                            Delivery_option(index_of_product);
                                            break;
                                        }
                                        else
                                        {
                                            Console.WriteLine("     Input bid amount is invalid");
                                        }
                                    }

                                }
                                else
                                {
                                    // Just same thing as previous codes but when bid already exists
                                    Console.WriteLine("Bidding for " + listproduct_name[Input_product_number - 1] + "(regular price " + listproduct_price[Input_product_number - 1] + "), current highest bid " + listbid_amount[Input_product_number - 1]);
                                    while (true)
                                    {
                                        Console.WriteLine("\nHow much do you bid?");

                                        string bid_price = Console.ReadLine();

                                        string Price_check = @"[$]+[0-9.,]+[0-9].{0,2}";
                                        if (Regex.IsMatch(bid_price, Price_check))
                                        {
                                            string find_index_of_product = Convert.ToString(listproduct_name[Input_product_number - 1]);
                                            int index_of_product = product_name.IndexOf(find_index_of_product);

                                            string current_bid = Convert.ToString(bid_amount[index_of_product]);
                                            string Current_bid = current_bid.Trim('$');
                                            double int_current_bid = Double.Parse(Current_bid);
                                            string bid_prices = bid_price.Trim('$');
                                            double int_bid_price = Double.Parse(bid_prices);

                                            if (int_current_bid < int_bid_price)
                                            {
                                                Useful_tools.Linechanger(Useremail, "Bidder_email.txt", index_of_product);
                                                Useful_tools.Linechanger(Username, "Bidder_name.txt", index_of_product);
                                                Useful_tools.Linechanger(bid_price, "Bid_amount.txt", index_of_product);
                                                string returns = ("\nYour bid of " + bid_price + " for " + listproduct_name[Input_product_number - 1] + "is placed.");
                                                Delivery_option(Input_product_number);
                                                break;
                                            }
                                            else
                                            {
                                                Console.WriteLine("        Input bid amount should be higher than current bid");
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("     Input bid amount is invalid");
                                        }

                                    }
                                }
                                break;
                            }
                            else
                            {
                                Console.WriteLine("     Please enter valid number.");
                            }
                        }
                    }
                }
            }
            else
            { // Search product with search phrase that user provided

                // int_search_phrase will be used to find the product with the word provided by user
                int[] int_search_phrase = new int[0];

                // This will make int search phrase as a list 
                var int_search_list = int_search_phrase.ToList();

                // This will find the index of product without logged in user advertised
                int[] VALUE = product_emailArray.Select((b, i) => b != Useremail ? i : -1).Where(i => i != -1).ToArray();
                // This will find the product with the phrase that user provided
                string[] result = Array.FindAll(product_nameArray, element => element.Contains(search_phrase));
                foreach (string str in result)
                {
                    // Find index of the product that user provided and add it on int_search_list
                    int_search_list.Add(product_name.IndexOf(str));
                    
                }
                if (result.Length == 0)
                {
                    // Find product and index of product with description if user provided not existing product name
                    string[] results = Array.FindAll(product_descriptionArray, element => element.Contains(search_phrase));
                    foreach (string str in results)
                    {
                        int_search_list.Add(product_description.IndexOf(str));
                    }
                }
                Console.WriteLine();
                List<int> product_intersection = (from num in VALUE
                                                  select num).Intersect(int_search_list).ToList();
                
                Console.WriteLine("\nSearch Results");
                Console.WriteLine("--------------");
                Console.WriteLine("\nItem #          Product name          Description          List price          Bidder name          Bidder email          Bid amt");
                int c = 0;
                foreach (int i in product_intersection)
                {
                    // Make another list to choose product with specific phrase
                    listproduct_name.Add(product_name[i]);
                    listproduct_description.Add(product_description[i]);
                    listproduct_price.Add(product_price[i]);
                    listbidder_name.Add(bidder_name[i]);
                    listbidder_email.Add(bidder_email[i]);
                    listbid_amount.Add(bid_amount[i]);
                    listdelivery_option.Add(delivery_option[i]);
                    c++;
                    Console.WriteLine(c + "                  " + product_name[i] + "                  " + product_description[i] + "                  " + product_price[i] + "                  " + bidder_name[i] + "                  " + bidder_email[i] + "                  " + bid_amount[i]);

                }

                if (c < 1)
                {
                    Console.WriteLine("None of the product have been searched");
                }
                else if (c >= 1)
                {
                    // Ask user to bid on product
                    Console.WriteLine("Would you like to place a bid on any of these items (yes or no)?");
                    string Response = Console.ReadLine();

                    if (Response.ToLower() == "yes")
                    {

                        while (true)
                        {

                            Console.WriteLine("Please enter a non-negative integer between 1 and " + c);
                            string str_Input_product_number = Console.ReadLine();
                            int input_product_number = Int32.Parse(str_Input_product_number);
                            int Input_product_number = input_product_number;
                            if (Input_product_number > 1 | Input_product_number < c + 1)
                            {
                                string is_bid_0 = Convert.ToString(listbid_amount[Input_product_number - 1]);

                                if (is_bid_0 == "-")
                                {

                                    while (true)
                                    {
                                        string current_bid_amount = "$0.00";
                                        Console.WriteLine("\nBidding for " + listproduct_name[Input_product_number - 1] + "(regular price " + listproduct_price[Input_product_number - 1] + "), current highest bid " + current_bid_amount);
                                        Console.WriteLine("\nHow much do you bid?");
                                        string bid_price = Console.ReadLine();
                                        string Price_check = @"([$]) *([0-9.,]*)";
                                        if (Regex.IsMatch(bid_price, Price_check))
                                        {
                                            string find_index_of_product = Convert.ToString(listproduct_name[Input_product_number - 1]);
                                            int index_of_product = product_name.IndexOf(find_index_of_product);
                                            Useful_tools.Linechanger(Useremail, "Bidder_email.txt", index_of_product);
                                            Useful_tools.Linechanger(Username, "Bidder_name.txt", index_of_product);
                                            Useful_tools.Linechanger(bid_price, "Bid_amount.txt", index_of_product);
                                            Console.WriteLine("\nYour bid of " + bid_price + " for " + listproduct_name[Input_product_number - 1] + "is placed.");
                                            Delivery_option(index_of_product);
                                            break;
                                        }
                                        else
                                        {
                                            Console.WriteLine("     Input bid amount is invalid");
                                        }
                                    }

                                }
                                else
                                {
                                    Console.WriteLine("Bidding for " + listproduct_name[Input_product_number - 1] + "(regular price " + listproduct_price[Input_product_number - 1] + "), current highest bid " + listbid_amount[Input_product_number - 1]);
                                    while (true)
                                    {
                                        Console.WriteLine("\nHow much do you bid?");

                                        string bid_price = Console.ReadLine();

                                        string Price_check = @"[$]+[0-9.,]+[0-9].{0,2}";
                                        if (Regex.IsMatch(bid_price, Price_check))
                                        {

                                            string find_index_of_product = Convert.ToString(listproduct_name[Input_product_number - 1]);
                                            int index_of_product = product_name.IndexOf(find_index_of_product);

                                            string current_bid = Convert.ToString(bid_amount[index_of_product]);
                                            string Current_bid = current_bid.Trim('$');
                                            double int_current_bid = Double.Parse(Current_bid);
                                            string bid_prices = bid_price.Trim('$');
                                            double int_bid_price = Double.Parse(bid_prices);

                                            if (int_current_bid < int_bid_price)
                                            {

                                                Useful_tools.Linechanger(Useremail, "Bidder_email.txt", index_of_product);
                                                Useful_tools.Linechanger(Username, "Bidder_name.txt", index_of_product);
                                                Useful_tools.Linechanger(bid_price, "Bid_amount.txt", index_of_product);
                                                Console.WriteLine("\nYour bid of " + bid_price + " for " + listproduct_name[Input_product_number - 1] + "is placed.");
                                                Delivery_option(index_of_product);
                                                break;
                                            }
                                            else
                                            {
                                                Console.WriteLine("        Input bid amount should be higher than current bid");
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("     Input bid amount is invalid");
                                        }

                                    }
                                }
                                break;
                            }
                            else
                            {
                                Console.WriteLine("     Please enter valid number.");
                            }
                        }

                    }
                    else if (Response.ToLower() == "no")
                    {
                        Console.WriteLine("Goes back to client menu");
                    }
                }
            }
        }
        // This will be used to confirm bid on the product
        public static void Confirm_bid(int index_username)
        {
            
            string[] product_emailArray = File.ReadAllLines(@"Product_email.txt");
            ArrayList product_email = new(product_emailArray);
            string[] product_nameArray = File.ReadAllLines(@"Product_name.txt");
            ArrayList product_name = new(product_nameArray);
            string[] product_descriptionArray = File.ReadAllLines(@"Product_description.txt");
            ArrayList product_description = new(product_descriptionArray);
            string[] product_priceArray = File.ReadAllLines(@"Product_price.txt");
            ArrayList product_price = new(product_priceArray);
            string[] bidder_nameArray = File.ReadAllLines(@"Bidder_name.txt");
            ArrayList bidder_name = new(bidder_nameArray);
            string[] bidder_emailArray = File.ReadAllLines(@"Bidder_email.txt");
            ArrayList bidder_email = new(bidder_emailArray);
            string[] bid_amountArray = File.ReadAllLines(@"Bid_amount.txt");
            ArrayList bid_amount = new(bid_amountArray);
            string[] useremailArray = File.ReadAllLines(@"Bid_owner_email.txt");
            ArrayList useremail = new(useremailArray);
            string[] Delivery_optionArray = File.ReadAllLines(@"Delivery_option.txt");
            ArrayList Delivery_option = new(Delivery_optionArray);

            ArrayList sellingproduct_name = new ArrayList();
            ArrayList sellingproduct_description = new ArrayList();
            ArrayList sellingproduct_price = new ArrayList();
            ArrayList sellingbidder_name = new ArrayList();
            ArrayList sellingbidder_email = new ArrayList();
            ArrayList sellingbid_amount = new ArrayList();
            ArrayList sellingDelivery_option = new ArrayList();


            string username = User.Username(index_username -1);
            string Input_Email = User.Useremail(index_username);


            // Listing the product by finding the product that has intersection between bid amount and bid owner email
            // bid amount means product that has bid on it and checking bid owner email is same as logged in user
            // which meeans check the product that has bid on it while its advertised by logged in user
            Console.WriteLine("\nList Product Bids for " + username + "(" + Input_Email + ")");
            int[] Bids = bid_amountArray.Select((b, i) => b != "-" ? i : -1).Where(i => i != -1).ToArray();
            int[] Bidders = useremailArray.Select((b, i) => b == Input_Email ? i : -1).Where(i => i != -1).ToArray();
            List<int> BID_intersection = (from num in Bids
                                          select num).Intersect(Bidders).ToList();
            Console.WriteLine("-----------------------------------------------");
            if (Bids.Length < 0)
            {
                Console.WriteLine("\nNo Bids were found.");
            }
            else if (Bids.Length > 0)
            {
                int p = 0;
                Console.WriteLine("\nItem #          Product name          Description          List price          Bidder name          Bidder email          Bid amt");
                foreach (int num in BID_intersection)
                {
                    p++;
                    Console.WriteLine(p + "                  " + product_name[num] + "                  " + product_description[num] + "                  " + product_price[num] + "                  " + bidder_name[num] + "                  " + bidder_email[num] + "                  " + bid_amount[num]);
                    // Make new list to select product
                    sellingproduct_name.Add(product_name[num]);
                    sellingproduct_description.Add(product_description[num]);
                    sellingproduct_price.Add(product_price[num]);
                    sellingbidder_name.Add(bidder_name[num]);
                    sellingbidder_email.Add(bidder_email[num]);
                    sellingbid_amount.Add(bid_amount[num]);
                    sellingDelivery_option.Add(Delivery_option[num]);
                }
                while (true)
                {

                    Console.WriteLine("\nWould you like to sell something (yes or no)?");
                    string sell = Console.ReadLine();
                    if (sell.ToLower() == "yes")
                    {

                        Console.WriteLine("\nPlease enter an integer between 1 and " + p + ":");
                        string strsell_option = Console.ReadLine();
                        int sell_option = Int32.Parse(strsell_option);
                        // 1 has been taken away because index starts with 0 but product number starts with 1
                        sell_option = sell_option - 1;
                        Console.WriteLine("\nYou have sold " + sellingproduct_name[sell_option] + " to " + sellingproduct_description[sell_option] + " for " + sellingbid_amount[sell_option] + ".");


                        // Add product on the file called Product_sold that has been sold
                        using (StreamWriter sr = new StreamWriter(@"Product_sold.txt", append: true))
                        {
                            sr.WriteLine(sellingbidder_email[sell_option]);
                            sr.WriteLine(Input_Email);
                            sr.WriteLine(sellingproduct_name[sell_option]);
                            sr.WriteLine(sellingproduct_description[sell_option]);
                            sr.WriteLine(sellingproduct_price[sell_option]);
                            sr.WriteLine(sellingbid_amount[sell_option]);
                            sr.WriteLine(sellingDelivery_option[sell_option]);
                            sr.WriteLine("");
                        }

                        // Delete product/bids from bid files and product files to not show on advertised product list anymore
                        // 1 has been added because 'linechanger' is already considering the -1 method but -1 has been done on this function to add purchased product
                        int delete = bidder_email.IndexOf(sellingbidder_email[sell_option]) + 1;
                        Useful_tools.Linechanger("", @"Bidder_email.txt", delete);
                        Useful_tools.Linechanger("", @"Bid_owner_email.txt", delete);
                        Useful_tools.Linechanger("", @"Bidder_name.txt", delete);
                        Useful_tools.Linechanger("", @"Bid_amount.txt", delete);
                        Useful_tools.Linechanger("", @"Product_name.txt", delete);
                        Useful_tools.Linechanger("", @"Product_description.txt", delete);
                        Useful_tools.Linechanger("", @"Product_email.txt", delete);
                        Useful_tools.Linechanger("", @"Product_price.txt", delete);
                        Useful_tools.Linechanger("", @"Bid.txt", delete);
                        Useful_tools.Linechanger("", @"Bid.txt", delete + 1);
                        Useful_tools.Linechanger("", @"Bid.txt", delete + 2);
                        Useful_tools.Linechanger("", @"Bid.txt", delete + 3);
                        Useful_tools.Linechanger("", @"Product.txt", delete);
                        Useful_tools.Linechanger("", @"Product.txt", delete + 1);
                        Useful_tools.Linechanger("", @"Product.txt", delete + 2);
                        Useful_tools.Linechanger("", @"Product.txt", delete + 3);
                        Useful_tools.Linechanger("", @"Delivery_option.txt", delete);

                        // Delete blank lines on the files
                        var lines = File.ReadAllLines(@"Bid.txt").Where(arg => !string.IsNullOrWhiteSpace(arg));
                        File.WriteAllLines(@"Bid.txt", lines);
                        var lines1 = File.ReadAllLines(@"Bidder_email.txt").Where(arg => !string.IsNullOrWhiteSpace(arg));
                        File.WriteAllLines(@"Bidder_email.txt", lines1);
                        var lines2 = File.ReadAllLines(@"Bid_owner_email.txt").Where(arg => !string.IsNullOrWhiteSpace(arg));
                        File.WriteAllLines(@"Bid_owner_email.txt", lines2);
                        var lines3 = File.ReadAllLines(@"Bidder_name.txt").Where(arg => !string.IsNullOrWhiteSpace(arg));
                        File.WriteAllLines(@"Bidder_name.txt", lines3);
                        var lines4 = File.ReadAllLines(@"Bid_amount.txt").Where(arg => !string.IsNullOrWhiteSpace(arg));
                        File.WriteAllLines(@"Bid_amount.txt", lines4);
                        var lines5 = File.ReadAllLines(@"Product_name.txt").Where(arg => !string.IsNullOrWhiteSpace(arg));
                        File.WriteAllLines(@"Product_name.txt", lines5);
                        var lines6 = File.ReadAllLines(@"Product_description.txt").Where(arg => !string.IsNullOrWhiteSpace(arg));
                        File.WriteAllLines(@"Product_description.txt", lines6);
                        var lines7 = File.ReadAllLines(@"Product_email.txt").Where(arg => !string.IsNullOrWhiteSpace(arg));
                        File.WriteAllLines(@"Product_email.txt", lines7);
                        var lines8 = File.ReadAllLines(@"Product_price.txt").Where(arg => !string.IsNullOrWhiteSpace(arg));
                        File.WriteAllLines(@"Product_price.txt", lines8);
                        var lines9 = File.ReadAllLines(@"Delivery_option.txt").Where(arg => !string.IsNullOrWhiteSpace(arg));
                        File.WriteAllLines(@"Delivery_option.txt", lines9);

                        break;

                    }
                    else if (sell.ToLower() == "no")
                    {
                        break;

                    }
                    else
                    {
                        Console.WriteLine("      Please write yes or no");
                    }
                }
            }
        }
        // This will be used to check the purchased product by logged in user
        public static void My_product(int email)
        {
            string[] Product_soldArray = File.ReadAllLines(@"Product_sold.txt");
            ArrayList Product_sold = new ArrayList(Product_soldArray);

            string username = User.Username(email -1);
            string Input_Email = User.Useremail(email);
            Console.WriteLine("\nPurchased items for " + username + "(" + Input_Email + ")");
            Console.WriteLine("-------------------------------------------------------");

            int[] VALUE = Product_soldArray.Select((b, i) => b == Input_Email ? i : -1).Where(i => i != -1).ToArray();

            if (VALUE.Length > 0)
            {

                // Find logged in user email on the product sold text file to find purchased product 
                int j = 0;
                Console.WriteLine("\nItem #         Seller name          Product name          Description          List price          Bidder name          Paid amount          Delivery option");
                foreach (int i in VALUE)
                {
                    j++;
                    Console.WriteLine(j + "                  " + Product_sold[i + 1]+"                  " + Product_sold[i + 2] + "                  " + Product_sold[i + 3] + "                  " + Product_sold[i + 4] + "                  " + Product_sold[i + 5] + "                  " + Product_sold[i + 6]);

                }

            }
            else
            {
                Console.WriteLine("\nYou have no purchased product at the moment.");
            }
        }
    }






    class Program
    {
        public static void Auction_house()
        {
            Main_Menu.Main();

        }
    }
}